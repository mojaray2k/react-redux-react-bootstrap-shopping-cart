# React Redux Shopping Cart
A small project that continues to reinforce the principles of Redux

## Getting Started
1. Run the command `git clone git@github.com:mojaray2k/redux-project-1.git` if you are using `ssh` or `git clone https://github.com/mojaray2k/redux-project-1.git` if you want to clone it over `https`;
2. Then once you have cloned it `cd` into `redux-project-1` and run `yarn` or `npm i`.
3. Then run the command `npm run dev` and then navigate to `localhost:5006` in your browser. 
4. If you want to change the `port` go into `server.js` and on line 13 change it from `5006` to what ever you choose. 
